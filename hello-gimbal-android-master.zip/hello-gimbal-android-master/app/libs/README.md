# Add these jar files

## gimbal-dev-logging.jar
## gimbal.jar
## spring-android-core-1.0.1.RELEASE.jar
## spring-android-rest-template-1.0.1.RELEASE.jar
